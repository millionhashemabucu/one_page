// Start Nav menu
const BtnHumber = document.getElementById('humberger');
const Btnnavigation = document.getElementById('navigation');


// Add class using 

BtnHumber.addEventListener('click',()=>{
    Btnnavigation.classList.toggle('toggle')
})

// Show And Remove botton 
window.addEventListener('scroll',()=>{
    let navshow = document.getElementById('top');
    (window.scrollY >= 44) ? navshow.classList.add('scroll')  : navshow.classList.remove('scroll');

})
// this is bottom to top
const BtnBottom = document.getElementById('top')
BtnBottom.addEventListener('click',()=>{
    window.scrollTo({
        top : 0,
        behavior: "smooth",
    })
})
console.log(BtnBottom)